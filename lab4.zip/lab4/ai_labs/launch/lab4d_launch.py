from launch import LaunchDescription
from launch_ros.actions import Node
from launch_ros.substitutions import FindPackageShare
from launch.substitutions import PathJoinSubstitution

def generate_launch_description():
    return LaunchDescription([
        Node(
            package='stage_ros2',
            executable='stage_ros2',
            name='stageros',
            output='screen',
            parameters=[{"world_file":
                PathJoinSubstitution([
                    FindPackageShare('ai_labs'),
                    'world/house.world'
                ])
            }]
        ),
        Node(
            package='ai_labs',
            executable='potential_fields',
            name='potential_fields',
            parameters=[{"next_waypoint": "-6.0 6.0 0.0"}]
        ),
    ])
